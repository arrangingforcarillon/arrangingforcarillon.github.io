Samples recorded on January 7, 2019 at St. Thomas Church, Whitemarsh (Fort Washington, PA)

48 bells by Petit & Fritsen, transposed 2 semitones up