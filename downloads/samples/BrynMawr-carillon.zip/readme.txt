Samples recorded on January 7, 2019 at Bryn Mawr Presbyterian Church.

49 bells by Petit & Fritsen, transposed 5 semitones up