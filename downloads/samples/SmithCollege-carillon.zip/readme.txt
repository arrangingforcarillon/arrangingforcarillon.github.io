Samples recorded on January 6, 2019 at Smith College (Northampton, MA)

47 bells by Paccard, transposed 3 semitones up